/* ###################################################################
**     Filename    : main.c
**     Project     : Simon Game
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2018-11-08, 01:15, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "RED_LED.h"
#include "TU1.h"
#include "GREEN_LED.h"
#include "BLUE_LED.h"
#include "TU2.h"
#include "TSS1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
/* User includes (#include below this line is not maintained by Processor Expert) */
#include "stdio.h"
#include "stdlib.h"
#include "time.h"

int ispressed=0;

//Wait function, wait_ms means let the system wait for xxx ms.
void wait (int wait_ms)
{
	int i,j;
	for(i=0;i<wait_ms;i++)
	{
		for(j=0;j<2500;j++)
		{
			__asm("nop");
		}
	}
}


//***Functions are added here to  turn on LED***
//Most of the LEDs are not turned on at full brightness to protect eyes

void Yellow()
{
	  RED_LED_SetRatio16(RED_LED_DeviceData,0xFF91);
	  GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0xE42B);
	  BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x0000);
}

void OFF()
{
	RED_LED_SetRatio16(RED_LED_DeviceData,0x0000);
	GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0x0000);
	BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x0000);
}

void White()
{
	RED_LED_SetRatio16(RED_LED_DeviceData,0x1FFF);
	GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0x1FFF);
	BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x1FFF);
}

void Purple()
{
	   RED_LED_SetRatio16(RED_LED_DeviceData,0x1FFF);
	   BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x1FFF);
	   GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0x0);
}

void Cyan()
{
	   GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0x1FFF);
	   BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x1FFF);
	   RED_LED_SetRatio16(RED_LED_DeviceData,0x0);
}

void Red()
{
	GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0x0000);
	BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x0000);
	RED_LED_SetRatio16(RED_LED_DeviceData,0x1FFF);
}

void Green()
{
	RED_LED_SetRatio16(RED_LED_DeviceData,0x0000);
	BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x0000);
	GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0x1FFF);
}

void Blue()
{
	RED_LED_SetRatio16(RED_LED_DeviceData,0x0000);
	GREEN_LED_SetRatio16(GREEN_LED_DeviceData,0x0000);
	BLUE_LED_SetRatio16(BLUE_LED_DeviceData,0x1FFF);
}

//Indication of GAME OVER
void Rainbow()
{
	int i=0, a=0xFFFF, b=0, c=0, inc = 218;
	int t=3;
	for (i=0;i<300;i++)
	{
		RED_LED_SetRatio16(RED_LED_DeviceData,a);
		GREEN_LED_SetRatio16(GREEN_LED_DeviceData,b);
		wait(t);
		b=b+inc;
	}

	for (i=0;i<300;i++)
	{
		GREEN_LED_SetRatio16(GREEN_LED_DeviceData,b);
		RED_LED_SetRatio16(RED_LED_DeviceData,a);
		wait(t);
		a=a-inc;
	}

	for (i=0;i<300;i++)
	{
		GREEN_LED_SetRatio16(GREEN_LED_DeviceData,b);
		BLUE_LED_SetRatio16(BLUE_LED_DeviceData,c);
		wait(t);
		c=c+inc;
	}

	for(i=0;i<300;i++)
	{
		GREEN_LED_SetRatio16(GREEN_LED_DeviceData,b);
		BLUE_LED_SetRatio16(BLUE_LED_DeviceData,c);
		wait(t);
		b=b-inc;
	}

	for(i=0;i<300;i++)
	{
		RED_LED_SetRatio16(RED_LED_DeviceData,a);
		BLUE_LED_SetRatio16(BLUE_LED_DeviceData,c);
		wait(t);
		a=a+inc;
	}

}
/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  //in sequence[], 3 means RED->a%3==0, 1 means GREEN->a%3==1, 2 means BLUE->a%3==2
  int sequence[50]={0};
  int missing[50]={0};
  int miss_compare[50]={0};//This sequence is to save the missing color and compared with user input
  int user[50]={0};
  int colornum=5;
  int missnum=1;
  int i=0, a=0, j=0,k=0; //i for sequence[], j for missing[], k for user[] & miss_compare[], a for random number
  int random;// random number for seeds
  int missrange=0;//from the missrange, to select a color miss
  int missstart=0;//the beginning(s) of missing number
  int is_iteration=0;
  int gameagain=1;
  int rest;//used in the iteration to generate missing sequence
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */


  //Turn off all the lights
  OFF();
  wait(10);


  //This loop ensures the games will start again after GAME OVER
 do
 {
	 //Initialize all the values
	  colornum=5;
	  missnum=1;
	  for(i=0;i<50;i++)
	  {
		  sequence[i]=0;
	  }

	  for(j=0;j<50;j++)
	  {
		  missing[j]=0;
	  }


	  //Indication of "Game is prepared". You should see a Yellow Color
	  Yellow();
	  wait(2000);
	  OFF();
	  wait(2000);

	  //Touch the pod and let the "Game Start"
  	  ispressed=0;
 	  while(ispressed<4)
 	  {
 		  TSS_Task();
 	  }
 	  random=TSS1_cKey0.Position;

 	  //Indication of successful press
 	  Red();
 	  wait(100);
 	  Green();
 	  wait(100);
 	  Blue();
 	  wait(100);
 	  OFF();
 	  wait(1000);


 	  srand(random);

 	  //Generate Random Sequence of Colors
 	  for(i=0;i<colornum;i++)
 	  {
 		  a=rand()%100+1;
 		  if(a%3==0)
 		  {
 			  Red();
 			  wait(1000);
 			  sequence[i]=3;
 			  OFF();
 			  wait(500);
 		  }
 		  else if(a%3==1)
 		  {
 			  Green();
 			  wait(1000);
 			  sequence[i]=1;
 			  OFF();
 			  wait(500);
 		  }
 		  else
 		  {
 			  Blue();
 			  wait(1000);
 			  sequence[i]=2;
 			  OFF();
 			  wait(500);
 		  }
 	  }

 	  //End of Sequence demonstration, Use Purple, Yellow, Cyan shining to indicate
 	  Purple();
 	  wait(100);
 	  Yellow();
 	  wait(100);
 	  Cyan();
 	  wait(100);
 	  OFF();
 	  wait(500);


 	  //Generate sequence with missing color(s)
 	  for(j=0;j<colornum;j++)
 	  {
 		  missing[j]=sequence[j];
 	  }


 	  missrange=colornum-0;//*** just for one trial, no iteration
 	  a=rand()%missrange+0; //*** Randomly choose the first the missing color
 	  miss_compare[0]=missing[a];
 	  missing[a]=-1;//-1 indicate the light here will miss in this sequence position

 	  for(j=0;j<colornum;j++)
 	  {
 		  if(missing[j]==3)
 		  {
 			  Red();
 			  wait(1000);
 			  OFF();
		 	wait(500);
 		  }
 		  else if(missing[j]==1)
 		  {
 			  Green();
 			  wait(1000);
 			  OFF();
 			  wait(500);
 		  }
 		  else if(missing[j]==2)
 		  {
 			  Blue();
 			  wait(1000);
 			  OFF();
 			  wait(500);
 		  }

 		  //Note where the color is missing, it will use a white light to indicate the exact position of missing color in the sequence[]
 		  else
 		  {
 			  White();
 			  wait(1000);
 			  OFF();
 			  wait(500);
 		  }
 	  }

 	  //End of Missing sequence demonstration, Use Purple, Yellow, Cyan shining to indicate
 	  Purple();
 	  wait(100);
 	  Yellow();
 	  wait(100);
 	  Cyan();
 	  wait(100);
 	  OFF();
 	  wait(500);

 	  //User Input, *** "wait()" can help to make the code more reliable with one input at a time***
 	  for(k=0;k<missnum;k++)
 	  {
 		  ispressed=0;
 		  while(ispressed<4)
 		  {
 			  TSS_Task();
 		  }
 		  if(TSS1_cKey0.Position>45)
	   	  {
 			  Blue();
 			  wait(500);
 			  user[k]=2;
	   	  }
	   	  else if (TSS1_cKey0.Position<=45 && TSS1_cKey0.Position>=10 )
	   	  {
	   		  Green();
	   		  wait(500);
	   		  user[k]=1;
	   	  }
	   	  else
	   	  {
	   		  Red();
	   		  wait(500);
	   		  user[k]=3;
	   	  }
 	  }
   	  //Processing ^-^
   	  OFF();
      wait(500);

      //Purple for correct, Cyan for Wrong
      if (user[0]==miss_compare[0])
      {
    	  Purple();
    	  wait(1000);
    	  OFF();
    	  wait(500);
    	  is_iteration=1;
      }
      else
      {
    	  Cyan();
    	  wait(1000);
    	  OFF();
    	  wait(500);
    	  is_iteration=0;

    	  Rainbow();
    	  OFF();
    	  wait(500);
      }

      // {Iteration}
      //Continuing Generating sequence[], each time add one color at the end of a sequence
      while(is_iteration==1)
      {
    	  colornum++;
    	  missnum++;
    	  for(i;i<colornum;i++) //Since i=5 in the first turn, i only for sequence[]
    	  {
    		  a=rand()%100+1;
    		  if(a%3==0)
    		  {
		  		 sequence[i]=3;
    		  }
    		  else if(a%3==1)
    		  {
		  		 sequence[i]=1;
    		  }
    		  else
    		  {
		  		 sequence[i]=2;
    		  }
    	  }

	   //Display the sequence of light
	   for(i=0;i<colornum;i++)
	   {
		   if(sequence[i]==3)
		   {
			   Red();
			   wait(1000);
			   OFF();
			   wait(500);
		   }
		   else if(sequence[i]==1)
		   {
			   Green();
			   wait(1000);
			   OFF();
			   wait(500);
		   }
		   else
		   {
			   Blue();
			   wait(1000);
			   OFF();
			   wait(500);
		   }
	   }

	   //End of Sequence demonstration, Use Purple, Yellow, Cyan shining to indicate
	   Purple();
	   wait(100);
	   Yellow();
	   wait(100);
	   Cyan();
	   wait(100);
	   OFF();
	   wait(500);

	   //Generate sequence with missing color(s)
	   for(j=0;j<colornum;j++)
	   {
	 	  missing[j]=sequence[j];
	   }

	   //Generate missing color(s) randomly
	   missstart=0;
	   rest=missnum;
	   missrange=(colornum-1)-(missnum-1);

	   for(j=0;j<missnum;j++)
	   {
		   a=rand()%(missrange)+missstart;// Randomly choose the position of missing color(s) in missing[]
		   miss_compare[j]=missing[a];
		   missing[a]=-1;
 		   missstart=a+1;//If there are more missing color needed, find the next starting position of next missing color in missing[]
 		   missrange=(colornum-1)-(rest-1)-missstart;//If there are more missing color needed, find the next range for next missing color in missing[]
 		   rest--;
	   }


	   //Display missing[] sequence
	   for(j=0;j<colornum;j++)
	   {
	 	  if(missing[j]==3)
	 	  {
	 		  Red();
	 		  wait(1000);
	 		  OFF();
	 		  wait(500);
	 	  }
	 	  else if(missing[j]==1)
	 	  {
	 		  Green();
	 		  wait(1000);
	 		  OFF();
	 		  wait(500);
	 	  }
	 	  else if(missing[j]==2)
	 	  {
	 		  Blue();
	 		  wait(1000);
	 		  OFF();
	 		  wait(500);
	 	  }
	 	  else
	 	  {
	 		  White();
	 		  wait(1000);
	 		  OFF();
	 		  wait(500);
	 	  }
	   }

	   //End of Missing sequence demonstration, Use Purple, Yellow, Cyan shining to indicate
	   Purple();
	   wait(100);
	   Yellow();
	   wait(100);
	   Cyan();
	   wait(100);
	   OFF();
	   wait(500);

	   //User Input
	   for(k=0;k<missnum;k++)
	   {
		     ispressed=0;
		     while(ispressed<4)
		     {
		   	  TSS_Task();
		     }

		     if(TSS1_cKey0.Position>45)
		   	 {
		   		   Blue();
		   		   wait(500);
		   		   OFF();
		   		   wait(100);
		   		   user[k]=2;
		   	 }
		     else if (TSS1_cKey0.Position<=45 && TSS1_cKey0.Position>=10 )
		   	 {
		   		   Green();
		   		   wait(500);
		   		   OFF();
		   		   wait(100);
		   		   user[k]=1;
		   	 }
		   	 else
		   	 {
		   		   Red();
		   		   wait(500);
		   		   OFF();
		   		   wait(100);
		   		   user[k]=3;
		   	 }
	   }
	   //Processing ^-^
	   OFF();
	   wait(500);

	   //Purple for Correct, Cyan for Wrong
	   for(k=0;k<missnum;k++)
	   {
		   if (user[k]!=miss_compare[k])
		   {
			   is_iteration=0;
		   }
	   }

	   //Display the result, if you lose the game, you will see a rainbow
	   if(is_iteration==1)
	   {
		   Purple();
		   wait(1000);
		   OFF();
		   wait(500);
	   }
	   else
	   {
		   Cyan();
		   wait(1000);
		   OFF();
		   wait(500);

		   Rainbow();
	       OFF();
	       wait(500);
	   }
   }

}while(gameagain==1);

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
